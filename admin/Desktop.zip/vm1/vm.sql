-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 25, 2018 at 06:37 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `vm`
--
CREATE DATABASE IF NOT EXISTS `vm` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `vm`;

-- --------------------------------------------------------

--
-- Table structure for table `detail`
--

CREATE TABLE IF NOT EXISTS `detail` (
  `id` int(250) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `user_id` int(100) NOT NULL,
  `email` varchar(1000) NOT NULL,
  `team_id` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `detail`
--

INSERT INTO `detail` (`id`, `name`, `user_id`, `email`, `team_id`) VALUES
(1, 'avanish', 687346, 'Avanish.singh2@cognizant.com', '0'),
(2, 'prince', 687360, 'prince.patrick@cognizant.com', '0'),
(3, 'subhrakanti', 687401, 'subhrakanti.sahoo@cognizant.com', '0');

-- --------------------------------------------------------

--
-- Table structure for table `live_vm`
--

CREATE TABLE IF NOT EXISTS `live_vm` (
  `rid` int(250) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `id` varchar(250) NOT NULL,
  `p_name` varchar(500) NOT NULL,
  `date` varchar(100) NOT NULL,
  `reason` varchar(5000) NOT NULL,
  `purpose` varchar(100) NOT NULL,
  `p_type` varchar(100) NOT NULL,
  `version` varchar(100) NOT NULL,
  `request_raised` int(100) NOT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(250) NOT NULL AUTO_INCREMENT,
  `user_id` int(250) NOT NULL,
  `name` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `admin` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `user_id`, `name`, `email`, `password`, `admin`) VALUES
(1, 687346, 'avanish', 'avanishsingh228@gmail.com', 'avanish', 1),
(2, 687360, 'prince', 'PrincePatrickAnand.Victor@cognizant.com', 'prince', 0);

-- --------------------------------------------------------

--
-- Table structure for table `new_vm_request`
--

CREATE TABLE IF NOT EXISTS `new_vm_request` (
  `rid` int(250) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `id` varchar(250) NOT NULL,
  `p_name` varchar(500) NOT NULL,
  `date` varchar(100) NOT NULL,
  `reason` varchar(5000) NOT NULL,
  `purpose` varchar(100) NOT NULL,
  `p_type` varchar(100) NOT NULL,
  `version` varchar(100) NOT NULL,
  `request_raised` int(100) NOT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `new_vm_request_date`
--

CREATE TABLE IF NOT EXISTS `new_vm_request_date` (
  `nid` int(250) NOT NULL AUTO_INCREMENT,
  `rid` int(250) NOT NULL,
  `id` int(250) NOT NULL,
  `p_name` varchar(500) NOT NULL,
  `new_date` varchar(500) NOT NULL,
  `purpose` varchar(100) NOT NULL,
  `reason` varchar(1000) NOT NULL,
  PRIMARY KEY (`nid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
