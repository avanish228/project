<?php
if(isset($_REQUEST["rid"])){
    session_start();
    require_once 'db.php';
    $sql="INSERT live_vm SELECT * FROM new_vm_request WHERE rid = ".$_REQUEST["rid"];
    $result = mysqli_query($con, $sql);
    if ($result)
	{   
        /*$sql = "SELECT * FROM detail where id=".$_REQUEST["id"]; 
        $result = mysqli_query($con, $sql); 
        $row = mysqli_fetch_array($result);
        $_SESSION["email"]=$row["email"];  
        $_SESSION["message"]="Your Request for new VM has been successfully accepted";
        $_SESSION["subject"]="New VM Request";
        $_SESSION["type"]="2";*/
        $sql="DELETE FROM new_vm_request WHERE rid = '".$_REQUEST["rid"]."'";
        $result = mysqli_query($con, $sql);
        if ($result){

        //header("location:mail/outlook.php");
		header("location:ShowAllVMAdmin.php");
        }
    
    }
    else {
        echo "Some error occured";

    }
}

?>