<?php

session_start();
require_once 'db.php';

if(!isset($_SESSION['email'])){
      header("location:index.php");
}
?>
<html>
    <head>
        <title>Show VM</title>
        <link rel="stylesheet" href="ShowAllVMAdmin.css">
    </head>
    <body>
        <nav>
            
            <h2>Welcome Admin </h2>
            <ul class="ulcontainer">
                <li><a href="PendingRequest.php" >Pending Requests</a></li>
                <li><a href="ExtendVMRequest.php">Extend Requests</a></li>
                <li><a href="ShowAllVMAdmin.php">Show All VM</a></li>
                <li><a href="../client/index.php" id="admin_login">Client Login</a></li>
                <li><a href="logout.php" id = "logout">Logout</a></li>
            </ul>
        </nav>
        <div class="main">
            <h4>Active VMs</h4>
            <div class="container">
                
                <table>
                    <tr>
                        <th>Requester Name</th>
                        <th>Requester id</th>
                        <th>Project Name</th>
                        <th>VM ID</th>
                        <th>Purpose</th>
                        <th>Expiry Date</th>
                    </tr>
                    <?php
                        $sql = "SELECT * FROM live_vm";  
                        $result = mysqli_query($con, $sql); 
                       while($row = mysqli_fetch_array($result))  
                       {  

                        echo '<tr>';
                        echo '<td>'.$row["name"].'</td>';
                        echo '<td>'.$row["id"].'</td>';
                        echo '<td>'.$row["p_name"].'</td>';
                        echo '<td>'.$row["rid"].'</td>';
                        echo '<td>'.$row["purpose"].'</td>';
                        echo '<td>'.$row["date"].'</td>';
                        
                        ?>
                    </tr>
                       <?php } ?>
                </table>
            </div>
            
        </div>
    </body>
</html>