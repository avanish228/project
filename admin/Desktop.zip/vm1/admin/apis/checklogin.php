<?php

session_start();
require_once 'db.php';

$email = $_POST['user'];
$password = $_POST['pass'];
/*$password = sha1($password);
$salt = md5("userlogin");
$peper = "hbjn/,";
$password = $password . $salt . $peper;
$password = stripslashes($password);*/
$sql = "SELECT * FROM `login` WHERE `user_id`='" . $email . "' and `password`='" . $password . "'";
$result = mysqli_query($con, $sql);
$count = mysqli_num_rows($result);

if ($count == 1)
	
	{
	$row = mysqli_fetch_assoc($result);
	$_SESSION['email']=$row['email'];
	header("location:../new_vm_request.php");
	
	}
  else
	{
	?>
<script type="text/javascript">
alert("Wrong username or password");
window.location.href = "../index.php";
</script>
<?php
	}

?>
