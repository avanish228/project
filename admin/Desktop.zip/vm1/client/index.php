<!DOCTYPE html>
<?php
session_start();
if(isset($_SESSION['email'])){
      header("location:ShowAllVM.php");
}
?>
<html>
    <head>
        <link rel="stylesheet" href="login.css">
    </head>
    <body>
        <div class="body"></div>
		<div class="grad"></div>
		<div class="header">
			<div>
                <span id="virtual">Virtual</span>
                <span id="machine">Machine</span>
                <span id = "allocation">Allocation</span>
                <span id = "systems">Systems</span>
            </div>
		</div>
		<br>
		<form class="login" action="apis/checklogin.php" method="POST">
				<input type="text" placeholder="Associate ID" name="user"><br>
				<input type="password" placeholder="password" name="pass"><br>
				<input type="submit" value="Login" name="submit">
                <p>Not a user? <a href="#">Click Here</a></p>
		</form>
    </body>
</html>