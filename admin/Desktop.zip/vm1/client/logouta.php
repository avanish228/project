<?php
session_start();
require_once 'db.php';

$sql = "SELECT * FROM `login` WHERE `user_id`='" . $_SESSION["user_id"] . "' and `admin`='" . 1 . "'";
$result = mysqli_query($con, $sql);
$count = mysqli_num_rows($result);

if ($count == 1)
	
	{
	$row = mysqli_fetch_assoc($result);
	$_SESSION['email']=$row['email'];
	header("location:../admin/PendingRequest.php");
	
	}
  else
	{
	?>
<script type="text/javascript">
alert("Sorry Only Admin has Access to this portal");
window.location.href = "ShowAllVM.php";
</script>
<?php
	}

?>
?>