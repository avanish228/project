<?php

session_start();
require_once 'db.php';
if(!isset($_SESSION['email'])){
      header("location:index.php");
}
?>
<html>
    <head>
        <title>Show VM</title>
        <link rel="stylesheet" href="ShowAllVM.css">
    </head>
    <body>
        <nav>
            
            <h2>Welcome <?php if(isset($_SESSION['name'])){ echo $_SESSION['name'];} ?></h2>
            <ul class="ulcontainer">
                <li><a href="RequestVM.php">Submit Request</a></li>
                <li><a href="ExtendVM.php">Extend Request</a></li>
                <li><a href="ShowAllVM.php">Show All VM</a></li>
                <li><a href="logouta.php" id="admin_login">Admin Login</a></li>
                <li><a href="logout.php" id = "logout">Logout</a></li>
            </ul>
        </nav>
        <div class="main">
            <h4>Active VM</h4>
            <div class="container">
                
                <table>
                    <tr>
                        <th>Project Name</th>
                        <th>VM ID</th>
                        <th>Expiry Date</th>
                        <th>Purpose</th>
                    </tr>
                    <?php
                        $sql = "SELECT * FROM live_vm where id='".$_SESSION['user_id']."'";  
                        $result = mysqli_query($con, $sql); 
                       while($row = mysqli_fetch_array($result))  
                       {  

                        echo '<tr>';
                        echo '<td>'.$row["p_name"].'</td>';
                        echo '<td>'.$row["rid"].'</td>';
                        echo '<td>'.$row["date"].'</td>';
                        echo '<td>'.$row["purpose"].'</td>';
                        ?>
                    </tr>
                       <?php } ?>
                </table>
            </div>
            
        </div>
    </body>
</html>