<?php

session_start();
require_once 'db.php';

if(!isset($_SESSION['email'])){
      header("location:index.php");
}
?>
<html>
    <head>
        <title>Extend VM</title>
        <link rel="stylesheet" href="ExtendVM.css">
    </head>
    <body>
        <nav>
            
            <h2>Welcome <?php if(isset($_SESSION['name'])){ echo $_SESSION['name'];} ?> </h2>
            <ul class="ulcontainer">
                <li><a href="RequestVM.php">Submit Request</a></li>
                <li><a href="ExtendVM.php">Extend Request</a></li>
                <li><a href="ShowAllVM.php">Show All VM</a></li>
                <li><a href="logouta.php" id="admin_login">Admin Login</a></li>
                <li><a href="logout.php" id = "logout">Logout</a></li>
            </ul>
        </nav>
        <div class="main">
            <h4>Extension Request</h4>
            <div class="container">
                <table>
                    <tr>
                        <th>Project Name</th>
                        <th>VM ID</th>
                        <th>Expiry Date</th>
                        <th>Purpose</th>
                        <th>Extend VM</th>
                        <th>Reason</th>
                    </tr>
                    <tr>
                        <?php
                        
                        $sql = "SELECT * FROM live_vm where id='".$_SESSION['user_id']."'";  
                        $result = mysqli_query($con, $sql); 
                       while($row = mysqli_fetch_array($result))  
                       {  
                    echo '<tr>';
                        echo '<td>'.$row["p_name"].'</td>';
                        echo '<td>'.$row["rid"].'</td>';
                        echo '<td>'.$row["date"].'</td>';
                        echo '<td>'.$row["purpose"].'</td>';
                        echo '<td>';
                        $date2=$row["date"];
	                    $date1 = date("Y-m-d");

                        $diff = abs(strtotime($date2) - strtotime($date1));
	                    $years = floor($diff / (365*60*60*24));
                        $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
                        $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
                        ?>
                        <form action='extend.php' method='POST'>
                        <select name="extendDate" <?php if($days > 7 || $row["request_raised"] == "1"){ echo "disabled";}?> required>
                                <option value="" selected disabled hidden>Select One</option>
                                <option value="1">One Week</option>
                                <option value="2">Two Weeks</option>
                                <option value="3">Three Weeks</option>
                                <option value="4">Four Weeks</option>
                            </select>
                        <?php
                        echo "<input type='hidden' value='".$row["rid"]."' name='rid'>";
                        echo "<input type='hidden' value='".$row["date"]."' name='pdate'>";
                        echo "<input type='hidden' value='".$row["p_name"]."' name='p_name'>";
                        echo "<input type='hidden' value='".$row["purpose"]."' name='purpose'>";
                        ?>
                        </td>
                        <td>
                            <textarea name="reason" cols="8" rows="2" placeholder="Reason for extension" <?php if($days > 7 || $row["request_raised"] == "1"){ echo "disabled";}?> required></textarea>
                        </td>
                        <td>
                            <input type="submit" id = "submit" name="submit" value="Submit" <?php if($days > 7 || $row["request_raised"] == "1"){ echo "disabled";}?> /></form>
                    </tr>
                       <?php } ?>
                </table>
            </div>
            
        </div>
    </body>
</html>