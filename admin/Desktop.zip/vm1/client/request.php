<?php
if(isset($_REQUEST["submit"])){
    session_start();
    $l=0;
    require_once 'db.php';
    $p_name=$_REQUEST["p_name"];
    $_SESSION["p_name"]=$p_name;
    $date = date("Y-m-d");
    $duration=7*((int)$_REQUEST["duration"]);
    $newdate = strtotime ( "$duration day" , strtotime ( $date ) ) ;
    $date = date ( 'Y-m-j' , $newdate );
    
    $_SESSION["duration"]=$duration;
    echo $duration;
    $reason=$_REQUEST["reason"];
    $_SESSION["reason"]=$reason;

    $purpose=$_REQUEST["purpose"];
    $_SESSION["purpose"]=$purpose;

    if($purpose == "team"){
                            if($_REQUEST["team_members"] == "mem1"){
                                $_SESSION["team_members"]="mem1";
                                $_SESSION["mem_name1"]=$_REQUEST["mem_name1"];
                                $_SESSION["mem_id1"]=$_REQUEST["mem_id1"];
                                $sql = "SELECT * FROM `detail` WHERE `name`='" . $_SESSION["mem_name1"] . "' and `user_id`='" . $_SESSION["mem_id1"] . "'";
                                $result = mysqli_query($con, $sql);
                                $count = mysqli_num_rows($result);
                                $row = mysqli_fetch_array($result);
                                $rid=$row["team_id"];
                                if($rid != 0){
                                    $l=1;
                                    ?>
                                    <script type="text/javascript">
                                    alert("team member <?php echo $_SESSION["mem_name1"]; ?> already in team id : <?php echo $rid; ?>");
                                    window.location.href = "requestVM.php";
                                    </script>
                                    <?php
                                }
                                if ($count == 0)
	                            {
                                    $l=1;
                                    ?>
                                    <script type="text/javascript">
                                    alert("team member <?php echo $_SESSION["mem_name1"]; ?> not found");
                                    window.location.href = "requestVM.php";
                                    </script>
                                    <?php
                                }

                            }
                            if($_REQUEST["team_members"] == "mem2"){
                                for($i=1;$i<=2;$i++){
                                $_SESSION["mem_name$i"]=$_REQUEST["mem_name$i"];
                                $_SESSION["mem_id$i"]=$_REQUEST["mem_id$i"];
                                $sql = "SELECT * FROM `detail` WHERE `name`='" . $_SESSION["mem_name$i"] . "' and `user_id`='" . $_SESSION["mem_id$i"] . "'";
                                $result = mysqli_query($con, $sql);
                                $count = mysqli_num_rows($result);
                                $row = mysqli_fetch_array($result);
                                $rid=$row["team_id"];
                                if($rid != 0){
                                    $l=1;
                                    ?>
                                    <script type="text/javascript">
                                    alert("team member <?php echo $_SESSION["mem_name$i"]; ?> already in team id : <?php echo $rid; ?>");
                                    window.location.href = "requestVM.php";
                                    </script>
                                    <?php
                                }
                                if ($count == 0)
	                            {$l=1;
                                    ?>
                                    <script type="text/javascript">
                                    alert("team member <?php echo $_SESSION["mem_name$i"]; ?> not found");
                                    window.location.href = "requestVM.php";
                                    </script>
                                    <?php
                                }
                            }
                            }
                            if($_REQUEST["team_members"] == "mem3"){
                                for($i=1;$i<=3;$i++){
                                $_SESSION["mem_name$i"]=$_REQUEST["mem_name$i"];
                                $_SESSION["mem_id$i"]=$_REQUEST["mem_id$i"];
                                $sql = "SELECT * FROM `detail` WHERE `name`='" . $_SESSION["mem_name$i"] . "' and `user_id`='" . $_SESSION["mem_id$i"] . "'";
                                $result = mysqli_query($con, $sql);
                                $count = mysqli_num_rows($result);
                                $row = mysqli_fetch_array($result);
                                $rid=$row["team_id"];
                                if($rid != 0){ $l=1;
                                    ?>
                                    <script type="text/javascript">
                                    alert("team member <?php echo $_SESSION["mem_name$i"]; ?> already in team id : <?php echo $rid; ?>");
                                    window.location.href = "requestVM.php";
                                    </script>
                                    <?php
                                }
                                if ($count == 0)
	                            {$l=1;
                                    ?>
                                    <script type="text/javascript">
                                    alert("team member <?php echo $_SESSION["mem_name$i"]; ?> not found");
                                    window.location.href = "requestVM.php";
                                    </script>
                                    <?php
                                }
                            }
                            }
                            if($_REQUEST["team_members"] == "mem4"){
                                for($i=1;$i<=4;$i++){
                                $_SESSION["mem_name$i"]=$_REQUEST["mem_name$i"];
                                $_SESSION["mem_id$i"]=$_REQUEST["mem_id$i"];
                                $sql = "SELECT * FROM `detail` WHERE `name`='" . $_SESSION["mem_name$i"] . "' and `user_id`='" . $_SESSION["mem_id$i"] . "'";
                                $result = mysqli_query($con, $sql);
                                $count = mysqli_num_rows($result);
                                $row = mysqli_fetch_array($result);
                                $rid=$row["team_id"];
                                if($rid != 0){$l=1;
                                    ?>
                                    <script type="text/javascript">
                                    alert("team member <?php echo $_SESSION["mem_name$i"]; ?> already in team id : <?php echo $rid; ?>");
                                    window.location.href = "requestVM.php";
                                    </script>
                                    <?php
                                }
                                if ($count == 0)
	                            {
                                    $l=1; ?>
                                    <script type="text/javascript">
                                    alert("team member <?php echo $_SESSION["mem_name$i"]; ?> not found");
                                    window.location.href = "requestVM.php";
                                    </script>
                                    <?php
                                }
                            }
                            }

    }
    $p_type=$_REQUEST["GuideProduct"];
    $version=$_REQUEST["version"];
    $name=$_SESSION["name"];
    $id=$_SESSION["user_id"];
    
        if($purpose == "team" ){
            if($l==0){
            $sql = "SELECT * FROM live_vm WHERE id = '" . $id . "' and `name`='" . $name . "' and `purpose`='" . $purpose . "'";
            $result = mysqli_query($con, $sql);
            $count = mysqli_num_rows($result);

            if($count <= 4){
                $sql="INSERT INTO `new_vm_request`(`name`, `id`, `p_name`, `date`, `reason`, `purpose`,`p_type`,`version`) VALUES ('".$_SESSION["name"]."','".$_SESSION["user_id"]."','$p_name','$date','$reason','$purpose','$p_type','$version')";
                $result= $con ->query($sql);
                $affected = $con ->affected_rows;
                if($affected == 1)
                {   
                        $sql = "SELECT * FROM new_vm_request WHERE id ='".$_SESSION["user_id"]."' and p_name='".$_SESSION["p_name"]."'";  
                        $result = mysqli_query($con, $sql);
                        $row = mysqli_fetch_assoc($result);
                        $rid=$row['rid'];
                    if($_REQUEST["team_members"] == "mem1"){
                        
                        if($_REQUEST["team_members"] == "mem1"){
                                $sql="UPDATE detail SET team_id = '".$rid."' WHERE `user_id` = '" . $_SESSION["mem_id1"] . "'";
                                $result= $con ->query($sql);
                                $affected = $con ->affected_rows;
                        }
                    }
                        if($_REQUEST["team_members"] == "mem2"){
                            for($i=1;$i<=2;$i++){
                            $sql="UPDATE detail SET team_id = '".$rid."' WHERE `user_id` = '" . $_SESSION["mem_id$i"] . "'";
                            $result= $con ->query($sql);
                            $affected = $con ->affected_rows;
                        }
                        }
                        if($_REQUEST["team_members"] == "mem3"){
                            for($i=1;$i<=3;$i++){
                                $sql="UPDATE detail SET team_id = '".$rid."' WHERE `user_id` = '" . $_SESSION["mem_id$i"] . "'";
                                $result= $con ->query($sql);
                                $affected = $con ->affected_rows;
                        }
                        }
                        if($_REQUEST["team_members"] == "mem4"){
                            for($i=1;$i<=4;$i++){
                                $sql="UPDATE detail SET team_id = '".$rid."' WHERE `user_id` = '" . $_SESSION["mem_id$i"] . "'";
                                $result= $con ->query($sql);
                                $affected = $con ->affected_rows;
                        }
                        }
                    
                /*$_SESSION["email"]="Avanish.Singh2@cognizant.com";
                $_SESSION["message"]="A New VM has been requested by $name for $reason upto $date kindly response";
                $_SESSION["subject"]="New VM Request";
                $_SESSION["type"]="1";
                header("location:mail/outlook.php");*/
                ?>
                <script type="text/javascript">
                alert("VM successfully requested");
                window.location.href = "requestVM.php";
                </script>
                <?php
                }
            
        }
            else{
				
				?>
<script type="text/javascript">
alert("You cannot request more than 4 VM for team");
window.location.href = "requestvm.php";
</script>
<?php
            }
        }
    }
        else{
            $sql = "SELECT * FROM `live_vm` WHERE `id`='" . $id . "' and `name`='" . $name . "' and `purpose`='" . $purpose . "'";
            $result = mysqli_query($con, $sql);
            $count = mysqli_num_rows($result);
            if($count == 1){
				?>
<script type="text/javascript">
alert("You cannot request more than 1 VM for yourself");
window.location.href = "requestvm.php";
</script>
<?php
            }
            else{
                $sql="INSERT INTO `new_vm_request`(`name`, `id`, `p_name`, `date`, `reason`, `purpose`,`p_type`,`version`) VALUES ('$name','$id','$p_name','$date','$reason','$purpose','$p_type','$version')";
                $result= $con ->query($sql);
                $affected = $con ->affected_rows;
                if($affected == 1)
                {
                /*$_SESSION["email"]="Avanish.Singh2@cognizant.com";
                $_SESSION["message"]="A New VM has been requested by $name for $reason upto $date kindly response";
                $_SESSION["subject"]="New VM Request";
                $_SESSION["type"]="1";
                header("location:mail/outlook.php");*/
				header("location:ShowAllVM.php");
                }
            }
        
    }
}