<?php

session_start();
require_once 'db.php';

$email = $_POST['user'];
$password = $_POST['pass'];
/*$password = sha1($password);
$salt = md5("userlogin");
$peper = "hbjn/,";
$password = $password . $salt . $peper;
$password = stripslashes($password);*/
$sql = "SELECT * FROM `login` WHERE `user_id`='" . $email . "' and `password`='" . $password . "'";
$result = mysqli_query($con, $sql);
$count = mysqli_num_rows($result);

if ($count == 1)
	
	{
	$l=0;
	$row = mysqli_fetch_assoc($result);
	$_SESSION['email']=$row['email'];
	$_SESSION['name']=$row['name'];
	$_SESSION['user_id'] = $email;
	$sql = "SELECT * FROM live_vm WHERE id ='".$_SESSION["user_id"]."'";  
    $result = mysqli_query($con, $sql); 
	while($row = mysqli_fetch_array($result))  
	{
	$date2=$row["date"];
	$date1 = date("Y-m-d");
    $diff = abs(strtotime($date2) - strtotime($date1));
	$years = floor($diff / (365*60*60*24));
    $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
	$days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
	echo $days;
	if($days <= 7){
		$l=1;
		 ?>
          <script type="text/javascript">
          alert("your VM <?php echo $row["rid"]; ?> will expire in <?php echo $days; ?> days" );
          window.location.href = "../ExtendVM.php";
          </script>
          <?php

	}
	 }
	 if($l == 0){
	header("location:../requestVM.php");
	 }
	}
  else
	{
	?>
<script type="text/javascript">
alert("Wrong username or password");
window.location.href = "../index.php";
</script>
<?php
	}

?>
