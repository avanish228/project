<?php
if(isset($_REQUEST["rid"])){
    session_start();

    if(!isset($_SESSION['email'])){
          header("location:index.php");
    }
    require_once 'db.php';
    $rid=$_REQUEST["rid"];
    $id=$_REQUEST["id"];
    $new_date=$_REQUEST["date"];
    $sql="UPDATE live_vm SET date='".$new_date."',request_raised=1 where rid='".$rid."'"; 
    $result= $con ->query($sql);
                $affected = $con ->affected_rows;
                if($affected == 1)
                {   
					$sql="DELETE FROM new_vm_request_date WHERE rid = '".$_REQUEST["rid"]."'";
                    $result = mysqli_query($con, $sql);
                    if ($result){
				    /*$sql = "SELECT * FROM detail where id=".$id; 
                    $result = mysqli_query($con, $sql); 
                    $row = mysqli_fetch_array($result);
                    $_SESSION["email"]=$row["email"]; 
                    $_SESSION["message"]="Date Extension request for VM for request id $rid has been accepted";
                    $_SESSION["subject"]="Date Extension Request ";
                    $_SESSION["type"]="5";
                    header("location:mail/outlook.php");*/
					header("location:ShowAllVMAdmin.php");
					}
                }
                else{
                    echo "ERROR OCCURED CONTACT ADMIN";
                }
}

?>