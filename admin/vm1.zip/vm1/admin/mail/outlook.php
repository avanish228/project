<?php
session_start();
$account="Avanish.Singh2@cognizant.com";
$password="";
$to=$_SESSION["email"];
$from="Avanish.Singh2@cognizant.com";
$from_name="ADMIN";
$msg=$_SESSION["message"]; // HTML message
$subject=$_SESSION["subject"];
/*End Config*/

include("phpmailer/class.phpmailer.php");
$mail = new PHPMailer();
$mail->IsSMTP();
$mail->CharSet = 'UTF-8';
$mail->Host = "smtp.live.com";
$mail->SMTPAuth= true;
$mail->Port = 587;
$mail->Username= $account;
$mail->Password= $password;
$mail->SMTPSecure = 'tls';
$mail->From = $from;
$mail->FromName= $from_name;
$mail->isHTML(true);
$mail->Subject = $subject;
$mail->Body = $msg;
$mail->addAddress($to);
if(!$mail->send()){
 echo "Mailer Error: " . $mail->ErrorInfo;
}else{
 echo "E-Mail has been sent";
 if($_SESSION["type"] == "1"){
     echo "<script>alert('VM requested successfully')</script>";
     header("location:../requestvm.php");
 }
 if($_SESSION["type"] == "2"){
    echo "<script>alert('VM successfully accepted')</script>";
    header("location:../new_vm_request.php");
}
if($_SESSION["type"] == "3"){
    echo "<script>alert('VM successfully rejected')</script>";
    header("location:../new_vm_request.php");
}
if($_SESSION["type"] == "5"){
    echo "<script>alert('Date successfully extended')</script>";
    header("location:../new_vm_request.php");
}
}
?>
