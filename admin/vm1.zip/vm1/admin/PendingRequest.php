<?php

session_start();
require_once 'db.php';

if(!isset($_SESSION['email'])){
      header("location:index.php");
}
?>
<html>
    <head>
        <title>Extend VM</title>
        <link rel="stylesheet" href="PendingRequest.css">
    </head>
    <body>
        <nav>
            
            <h2>Welcome Admin </h2>
            <ul class="ulcontainer">
                <li><a href="PendingRequest.php" >Pending Requests</a></li>
                <li><a href="ExtendVMRequest.php">Extend Requests</a></li>
                <li><a href="ShowAllVMAdmin.php">Show All VM</a></li>
                <li><a href="../client/index.php" id="admin_login">Client Login</a></li>
                <li><a href="logout.php" id = "logout">Logout</a></li>
            </ul>
        </nav>
        <div class="main">
            <h4>Pending Requests</h4>
            <div class="container">
                <table>
                    <tr>
                        <th>Requester's Name</th>
                        <th>Requester's Id</th>
                        <th>Project Name</th>
                        <th>VM ID</th>
                        <th>Expiry Date</th>
                        <th>Reason</th>
                    </tr>
                    <?php
                        $sql = "SELECT * FROM new_vm_request";  
                        $result = mysqli_query($con, $sql); 
                       while($row = mysqli_fetch_array($result))  
                       {  

                            echo "<tr>";
                            echo "<td>".$row["name"]."</td>";
                            echo "<td>".$row["id"]."</td>";
                            echo "<td>".$row["p_name"]."</td>";
                            echo "<td>".$row["rid"]."</td>";
                            echo "<td>".$row["date"]."</td>";
                            echo "<td>".$row["reason"]."</td>";
                            echo "<td id='action'>";
                        ?>
                                    <a href=<?php echo "accept.php?rid=".$row["rid"]."&id=".$row['id']; ?> ><button class="btn btn-success" id="accept" >Approve</button></a>
                                    <a href=<?php echo "reject.php?id=".$row["rid"]; ?>><button class="btn btn-danger" id="reject" >Reject</button></a>
                                
                            </td>
                             
                            </tr>
                       <?php } ?>
                    
                </table>
            </div>
            
        </div>
    </body>
</html>