<html>
    <head>
        <title>Extend VM</title>
        <link rel="stylesheet" href="ExtendVMRequest.css">
    </head>
    <body>
        <nav>
            
            <h2>Welcome {name} </h2>
            <ul class="ulcontainer">
                <li><a href="../PendingRequest/PendingRequest.html">Pending Requests</a></li>
                <li><a href="../ExtendVMRequest/ExtendVMRequest.php">Extend Requests</a></li>
                <li><a href="../ShowAllVMAdmin/ShowAllVMAdmin.html">Show All VM</a></li>
                <li><a href="logouta.php" id="admin_login">Admin Login</a></li>
                <li><a href="../login/login.html" id = "logout">Logout</a></li>
            </ul>
        </nav>
        <div class="main">
            <h4>Extention Requests</h4>
            <div class="container">
                <table>
                    <tr>
                        <th>Requester's Name</th>
                        <th>VM Name</th>
                        <th>VM ID</th>
                        <th>Expiry Date</th>
                        <th>Extended Date</th>
                        <th>Reason</th>
                    </tr>
                    <tr>
                        <td>Name</td>
                        <td>VM01</td>
                        <td>1234</td>
                        <td>14/05/2018</td>
                        <td>14/06/2018</td>
                        <td>Reason</td>
                        <td>
                            <div id="btn">
                                <button id = "accept">Accept</button>
                                <button id = "reject">Reject</button>
                            </div>
                        </td>
                    </tr>
                    
                </table>
            </div>
            
        </div>
    </body>
</html>