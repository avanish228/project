<?php
 session_start();

 if(!isset($_SESSION['email'])){
       header("location:index.php");
 }
if(isset($_REQUEST["submit"])){
 require_once 'db.php';
 $rid=$_REQUEST['rid'];
 $id=$_SESSION['user_id'];
 
 $p_name=$_REQUEST['p_name'];
 $reason=$_REQUEST['reason'];

    $date = $_REQUEST['pdate'];
    $duration=7*((int)$_REQUEST['extendDate']);
    $newdate = strtotime ( "$duration day" , strtotime ( $date ) ) ;
    $new_date= date ( 'Y-m-j' , $newdate );

 $purpose=$_REQUEST['purpose'];
                $sql="INSERT INTO `new_vm_request_date`(`rid`,`id`, `p_name`, `new_date`,`purpose`,`reason`) VALUES ('".$rid."','".$id."','".$p_name."','".$new_date."','".$purpose."','".$reason."'  )";
                $result= $con ->query($sql);
                $affected = $con ->affected_rows;
                if($affected == 1)
                {   
                    $sql="UPDATE live_vm SET request_raised=1 where rid='".$rid."'";
                    $result= $con ->query($sql);
                    /*$_SESSION["email"]="Avanish.Singh2@cognizant.com";
                    $_SESSION["message"]="Date Extension request for VM has been requested by $id for $p_name project upto $new_date kindly response";
                    $_SESSION["subject"]="Date Extension Request Request";
                    $_SESSION["type"]="4";
                    header("location:mail/outlook.php");*/
					header("location:ShowAllVM.php");
                }


}

?>