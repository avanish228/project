<?php

session_start();

if(!isset($_SESSION['email'])){
      header("location:index.php");
}
?>
<html>
<head>
        <title>Request New VM</title>
        <link rel="stylesheet" href="requestVM.css">
        <script src="https://code.jquery.com/jquery-3.3.1.min.js"
            integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
            crossorigin="anonymous"></script>
        <script type="text/javascript" src="requestVMJS.js"></script>
    </head>
    <body>
        <nav>
        <h2>Welcome <?php if(isset($_SESSION['name'])){ echo $_SESSION['name'];} ?></h2>
            <ul class="ulcontainer">
                <li><a href="RequestVM.php">Submit Request</a></li>
                <li><a href="ExtendVM.php">Extend Request</a></li>
                <li><a href="ShowAllVM.php">Show All VM</a></li>
                <li><a href="logouta.php" id="admin_login">Admin Login</a></li>
                <li><a href="logout.php" id = "logout">Logout</a></li>
            </ul>
            
        </nav>
        <div class="main">
            <h1>VM Request</h1>
            
            <div class="container">
                
                <form action="request.php" method="">
                    <label>Project ID</label>
                    <input class = "long-width" name="p_id" type="text" placeholder="Project ID" required>
                    <label>Project Name</label>
                     <input class = "long-width" type="text" name="p_name" placeholder="Project Name" required>
                     <label> Reason for Request</label>
                    <textarea class = "long-width" rows="3" cols="22" name="reason" placeholder="Reason for Request" required></textarea>
                    <label>Duration In Weeks</label>
                    <select class="duration" name="duration">
                        <option value="1">One Week</option>
                        <option value="2">Two Weeks</option>
                        <option value="3">Three Weeks</option>
                        <option value="4">Four Weeks</option>
                    </select>
                    <label>Purpose:</label>
                    <input id="radio_st" type="radio" name="purpose" value="self" onclick="show1();" required>Self
                    <input id="radio_st" type="radio" name="purpose" value="team" onclick="show2();" required>Team

                    <!--<div id="blank_div" class="togglehs"></div>-->
                    <div id="show_team" class="togglehs">
                        <select name="team_members" id = "selected_mem" onchange="enadis()">
                            <option value="" selected disabled hidden>Select One</option>
                            <option value="mem1">One Member</option>
                            <option value="mem2">Two Members</option>
                            <option value="mem3">Three Members</option>
                            <option value="mem4">Four Members</option>
                        </select>
                        <div class="smallbox">
                            <input class = "short-mem" id="id1" type="text" placeholder="Member 1 Name" name="mem_name1"> 
                            <input clas= "short-mem" id="id_1" type="text" placeholder="Member 1 Associate ID" name="mem_id1">
                        </div>
                        <div class="smallbox">
                            <input class = "short-mem" id="id2" type="text" placeholder="Member 2 Name" name="mem_name2"> 
                            <input class= "short-mem" id="id_2" type="text" placeholder="Member 2 Associate ID" name="mem_id2">
                        </div>
                        <div class="smallbox">
                            <input class = "short-mem" id="id3" type="text" placeholder="Member 3 Name" name="mem_name3"> 
                            <input class= "short-mem" id="id_3" type="text" placeholder="Member 3 Associate ID" name="mem_id3">
                        </div>
                        <div class="smallbox">
                            <input class = "short-mem" id="id4" type="text" placeholder="Member 4 Name" name="mem_name4"> 
                            <input class= "short-mem" id="id_4" type="text" placeholder="Member 4 Associate ID" name="mem_id4">
                        </div>
                    </div>

                    <h4>GuideWire Product: </h4>
                    <span>
                        PC:<input type="radio" name="GuideProduct" class="PC" value="pc"  required onclick="pcfun();">
                        <select class="PC" id="pc" name="version">
                            <option value="" selected disabled hidden>Select Version</option>
                            <option value="Version 1">Version 1</option>
                            <option value="Version 2">Version 2</option>
                        </select></br>
                    </span>
                    <span>
                        BC:<input type="radio" name="GuideProduct" class="BC" value="bc" required onclick="bcfun();">
                        <select class="BC" id="bc" name="version">
                            <option value="" selected disabled hidden>Select Version</option>
                            <option value="Version 1">Version 1</option>
                            <option value="Version 2">Version 2</option>
                        </select></br>
                    </span>
                    <span>
                        CC:<input type="radio" name="GuideProduct" class="CC" value="cc"  required onclick="ccfun();">
                        <select class="CC" id="cc" name="version">
                            <option value="" selected disabled hidden>Select Version</option>
                            <option value="Version 1">Version 1</option>
                            <option value="Version 2">Version 2</option>
                        </select></br>
                    </span>
                    <button class = "long-width" name="submit" vamle="submit" id ="submit">Submit</button>
                </form>
            </div>
        </div>
        
    </body>
</html>